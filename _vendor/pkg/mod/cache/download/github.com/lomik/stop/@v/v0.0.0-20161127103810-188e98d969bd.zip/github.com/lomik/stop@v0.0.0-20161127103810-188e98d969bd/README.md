# stop
Helper for objects with Stop method
